This project contains several C programs demonstrating process creation, process control, linking multiple source files, and basic loader behavior in Linux. The examples are based on Operating Systems Lab 5 and are organized using a Makefile to automate compilation.



installation



we only need GCC installed on our Linux system. All examples compile using standard GNU tools, and the Makefile includes all necessary build targets.



usage



To compile everything:

make

Run each program:

./process\_creation
./output\_program
./simple\_program



features



Demonstrates fork() and process creation

Includes examples requiring a linker to combine files

Examines dynamic libraries using ldd

Automated compilation with a Makefile



lisence



This project uses an open-source license (see LICENSE file in the repository).



