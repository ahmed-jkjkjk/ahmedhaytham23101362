#include <stdio.h>

void hello() {
    printf("Hello from file1!\n");
}
